package com.example.gpt4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
