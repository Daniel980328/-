import 'package:http/http.dart' as http;
import 'dart:convert';

const String baseUrl = "http://10.0.2.2:8080/leaderboard";

// 상위 10명 기록 가져오기
Future<List<Map<String, dynamic>>> fetchLeaderboardFromApi() async {
  try {
    final response = await http.get(Uri.parse(baseUrl));
    if (response.statusCode == 200) {
      return List<Map<String, dynamic>>.from(json.decode(response.body));
    } else {
      throw Exception("Failed to fetch leaderboard: ${response.statusCode}");
    }
  } catch (e) {
    print("Error fetching leaderboard: $e");
    throw Exception("An error occurred while fetching the leaderboard");
  }
}

// 새로운 기록 추가
Future<void> addRecordToApi(String initials, int time) async {
  try {
    final response = await http.post(
      Uri.parse(baseUrl),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({'initials': initials, 'time': time}),
    );
    if (response.statusCode != 200) {
      throw Exception(
          "Failed to add record: ${response.statusCode} - ${response.body}");
    }
  } catch (e) {
    print("Error adding record: $e");
    throw Exception("An error occurred while adding the record");
  }
}
