import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'leaderboard_provider.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({Key? key}) : super(key: key);

  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  Offset playerPosition = const Offset(200, 400);
  List<Map<String, dynamic>> obstacles = [];
  bool isGameOver = false;
  Stopwatch stopwatch = Stopwatch();
  Random random = Random();

  @override
  void initState() {
    super.initState();
    stopwatch.start();

    // 주기적으로 장애물 이동 및 충돌 감지
    Timer.periodic(const Duration(milliseconds: 16), (timer) {
      if (isGameOver) {
        timer.cancel();
        return;
      }
      moveObstacles();
      checkCollision();
    });

    // 장애물 생성
    spawnObstacles();
  }

  void spawnObstacles() {
    Timer.periodic(const Duration(seconds: 2), (timer) {
      if (isGameOver) {
        timer.cancel();
        return;
      }
      setState(() {
        obstacles.add({
          "position": Offset(
            random.nextDouble() * MediaQuery.of(context).size.width,
            0,
          ),
          "dx": (random.nextDouble() * 2 - 1) * 5,
          "dy": random.nextDouble() * 5 + 2,
        });
      });
    });
  }

  void moveObstacles() {
    setState(() {
      for (int i = 0; i < obstacles.length; i++) {
        var obstacle = obstacles[i];
        var position = obstacle["position"] as Offset;
        var dx = obstacle["dx"] as double;
        var dy = obstacle["dy"] as double;

        // 벽 충돌 처리
        if (position.dx <= 0 || position.dx >= MediaQuery.of(context).size.width) {
          dx = -dx + (random.nextDouble() * 1 - 0.5);
        }
        if (position.dy <= 0 || position.dy >= MediaQuery.of(context).size.height) {
          dy = -dy + (random.nextDouble() * 1 - 0.5);
        }

        // 장애물 이동 업데이트
        obstacles[i] = {
          "position": Offset(position.dx + dx, position.dy + dy),
          "dx": dx,
          "dy": dy,
        };
      }
    });
  }

  void checkCollision() {
    for (var obstacle in obstacles) {
      if ((playerPosition - (obstacle["position"] as Offset)).distance < 30) {
        setState(() {
          isGameOver = true;
        });
        stopwatch.stop();
        endGame();
        break;
      }
    }
  }

  void endGame() async {
    int survivalTime = stopwatch.elapsed.inSeconds;
    String initials = "";

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Game Over"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("You survived for $survivalTime seconds."),
              TextField(
                onChanged: (value) => initials = value.toUpperCase(),
                maxLength: 3,
                decoration: const InputDecoration(hintText: "Enter initials"),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () async {
                if (initials.isNotEmpty) {
                  await Provider.of<LeaderboardProvider>(context, listen: false)
                      .addRecord(initials, survivalTime);
                  Navigator.pop(context);
                  Navigator.pop(context);
                }
              },
              child: const Text("Submit"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanUpdate: (details) {
        setState(() {
          playerPosition = Offset(
            playerPosition.dx + details.delta.dx,
            playerPosition.dy + details.delta.dy,
          );
        });
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            // 플레이어
            Positioned(
              left: playerPosition.dx,
              top: playerPosition.dy,
              child: Container(
                width: 30,
                height: 30,
                decoration: const BoxDecoration(
                  color: Colors.blue,
                  shape: BoxShape.circle,
                ),
              ),
            ),
            // 장애물
            ...obstacles.map((obstacle) {
              return Positioned(
                left: (obstacle["position"] as Offset).dx,
                top: (obstacle["position"] as Offset).dy,
                child: Container(
                  width: 20,
                  height: 20,
                  decoration: const BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.circle,
                  ),
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }
}
