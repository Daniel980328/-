import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'main_menu.dart';
import 'leaderboard_provider.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LeaderboardProvider()),
      ],
      child: const MaterialApp(home: MainMenu()),
    ),
  );
}
