import 'package:flutter/material.dart';
import 'api_service.dart';

class LeaderboardProvider with ChangeNotifier {
  List<Map<String, dynamic>> _leaderboard = [];
  bool _isLoading = false;

  List<Map<String, dynamic>> get leaderboard => _leaderboard;
  bool get isLoading => _isLoading;

  Future<void> fetchLeaderboard() async {
    _isLoading = true;
    notifyListeners();
    try {
      _leaderboard = await fetchLeaderboardFromApi();
    } catch (e) {
      debugPrint("Failed to fetch leaderboard: $e");
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addRecord(String initials, int time) async {
    try {
      await addRecordToApi(initials, time);
      await fetchLeaderboard(); // 리더보드 갱신
    } catch (e) {
      debugPrint("Failed to add record: $e");
    }
  }
}
