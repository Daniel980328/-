import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'leaderboard_provider.dart';

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Leaderboard"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              Provider.of<LeaderboardProvider>(context, listen: false)
                  .fetchLeaderboard();
            },
          ),
        ],
      ),
      body: Consumer<LeaderboardProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }
          final leaderboard = provider.leaderboard;
          return ListView.builder(
            itemCount: leaderboard.length,
            itemBuilder: (context, index) {
              final record = leaderboard[index];
              return ListTile(
                title: Text("${index + 1}. ${record['initials']}"),
                subtitle: Text("Time: ${record['time']} seconds"),
              );
            },
          );
        },
      ),
    );
  }
}
